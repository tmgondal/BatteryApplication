import os
import pandas as pd

def generate_report(run_id: str, features: dict, prediction: str,
                    probability: float, shap_values: dict, out_folder: str) -> str:
    """
    Build a multi‐sheet Excel report:
      - Sheet "Features": each row ― feature name, value
      - Sheet "Summary": prediction + probability
      - Sheet "SHAP": each row ― feature name, shap_value
    Returns: full path to the saved .xlsx file.
    """
    # 1) Build DataFrame for features
    df_feat = pd.DataFrame.from_dict(features, orient="index", columns=["value"])
    df_feat.index.name = "feature"
    df_feat.reset_index(inplace=True)

    # 2) Build DataFrame for SHAP
    df_shap = pd.DataFrame.from_dict(shap_values, orient="index", columns=["shap_value"])
    df_shap.index.name = "feature"
    df_shap.reset_index(inplace=True)

    # 3) Summary sheet
    summary_df = pd.DataFrame({
        "prediction": [prediction],
        "probability": [probability]
    })

    # 4) Write to Excel
    report_name = f"{run_id}_report.xlsx"
    report_path = os.path.join(out_folder, report_name)
    with pd.ExcelWriter(report_path, engine="openpyxl") as writer:
        df_feat.to_excel(writer, sheet_name="Features", index=False)
        summary_df.to_excel(writer, sheet_name="Summary", index=False)
        df_shap.to_excel(writer, sheet_name="SHAP", index=False)

    return report_path
