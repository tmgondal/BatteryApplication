# backend/app.py

import os
import uuid
import datetime
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
from processing.eis_hppc import extract_eis_features, extract_hppc_features
from ml.dummy_model import load_model_and_predict

# --------------------------------------------------------
#  CONFIGURATION
# --------------------------------------------------------
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
ALLOWED_EXTENSIONS = {"xlsx", "xls"}

# Ensure uploads folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB max file size

def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )

# --------------------------------------------------------
#  ROUTES
# --------------------------------------------------------
@app.route("/upload/eis", methods=["POST"])
def upload_eis():
    """
    Expects form-data: key="file", value=Excel (.xlsx/.xls) containing EIS data.
    Returns JSON: { success: bool, features: { Rs, Rct, ... }, model_score: float }
    """
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": False, "error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        # Make a secure filename + unique suffix
        original_name = secure_filename(file.filename)
        uid = uuid.uuid4().hex
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        saved_filename = f"{uid}_{timestamp}_{original_name}"
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], saved_filename)
        file.save(save_path)

        # 1) Extract EIS features
        try:
            eis_feats = extract_eis_features(save_path)
        except Exception as e:
            return jsonify(
                {"success": False, "error": f"EIS extraction failed: {e}"}
            ), 500

        # 2) Load a dummy ML model and get prediction
        try:
            model_score = load_model_and_predict(eis_feats)
        except Exception as e:
            return jsonify(
                {"success": False, "error": f"Model inference failed: {e}"}
            ), 500

        return jsonify(
            {"success": True, "features": eis_feats, "model_score": model_score}
        )

    return jsonify({"success": False, "error": "File type not allowed"}), 400


@app.route("/upload/hppc", methods=["POST"])
def upload_hppc():
    """
    Expects form-data: key="file", value=Excel (.xlsx/.xls) containing HPPC data.
    Returns JSON: { success: bool, features: { capacity, internal_resistance, SoH, ... }, model_score: float }
    """
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": False, "error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        original_name = secure_filename(file.filename)
        uid = uuid.uuid4().hex
        timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        saved_filename = f"{uid}_{timestamp}_{original_name}"
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], saved_filename)
        file.save(save_path)

        # 1) Extract HPPC features
        try:
            hppc_feats = extract_hppc_features(save_path)
        except Exception as e:
            return jsonify(
                {"success": False, "error": f"HPPC extraction failed: {e}"}
            ), 500

        # 2) Load a dummy ML model and get prediction
        try:
            model_score = load_model_and_predict(hppc_feats)
        except Exception as e:
            return jsonify(
                {"success": False, "error": f"Model inference failed: {e}"}
            ), 500

        return jsonify(
            {"success": True, "features": hppc_feats, "model_score": model_score}
        )

    return jsonify({"success": False, "error": "File type not allowed"}), 400


if __name__ == "__main__":
    # Run in debug mode during development
    app.run(host="0.0.0.0", port=5000, debug=True)
