import os
import json
import pickle
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from ml.pipeline import FeaturePipeline

class BatteryRepurposeModel:
    """
    Encapsulates:
      - Loading or initializing a RandomForest + StandardScaler (versioned)
      - predict_and_explain(): returns (label, probability, shap_dict)
      - retrain(): refit on a full DataFrame + labels, bump version
    """

    def __init__(self, models_dir: str):
        self.models_dir = models_dir
        os.makedirs(self.models_dir, exist_ok=True)

        # Metadata.json stores { "current_version": "v1", "history": ["v1", ...] }
        self.meta_path = os.path.join(self.models_dir, "metadata.json")
        if not os.path.exists(self.meta_path):
            # First run: initialize metadata and a baseline model (untrained)
            initial_meta = {"current_version": "v1", "history": ["v1"]}
            with open(self.meta_path, "w") as f:
                json.dump(initial_meta, f)

            # Create a dummy RandomForest + scaler
            self.scaler = StandardScaler()
            self.clf = RandomForestClassifier(n_estimators=100, random_state=42)
            self._save_version("v1")
        else:
            # If metadata exists, load current_version and then load the pickles
            with open(self.meta_path, "r") as f:
                meta = json.load(f)
            self.current_version = meta["current_version"]
            self._load_version(self.current_version)

    def _save_version(self, version: str):
        """
        Serialize self.scaler and self.clf to:
          - scaler_<version>.pkl
          - model_<version>.pkl
        Then update metadata.json → current_version = version; append version to history if new.
        """
        scaler_path = os.path.join(self.models_dir, f"scaler_{version}.pkl")
        model_path = os.path.join(self.models_dir, f"model_{version}.pkl")
        with open(scaler_path, "wb") as f:
            pickle.dump(self.scaler, f)
        with open(model_path, "wb") as f:
            pickle.dump(self.clf, f)

        with open(self.meta_path, "r+") as f:
            meta = json.load(f)
            meta["current_version"] = version
            if version not in meta["history"]:
                meta["history"].append(version)
            f.seek(0)
            json.dump(meta, f)
            f.truncate()

        self.current_version = version

    def _load_version(self, version: str):
        """
        Load pickles for a given version:
          - scaler_<version>.pkl
          - model_<version>.pkl
        """
        scaler_path = os.path.join(self.models_dir, f"scaler_{version}.pkl")
        model_path = os.path.join(self.models_dir, f"model_{version}.pkl")
        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)
        with open(model_path, "rb") as f:
            self.clf = pickle.load(f)

    def predict_and_explain(self, feature_dict: dict):
        """
        1) Build a single-row DataFrame from feature_dict
        2) Transform via FeaturePipeline (impute/mask/order columns)
        3) Scale via self.scaler
        4) Predict probability; label = "repurpose" if prob ≥ 0.5 else "not_repurpose"
        5) Compute SHAP values for class=1 and return as a dict{feature: shap_value}
        Returns: (label: str, probability: float, shap_dict: dict)
        """
        import shap

        # 1) DataFrame with one row
        df_in = pd.DataFrame([feature_dict])

        # 2) Preprocess features (ordering, missing → 0)
        x_processed = FeaturePipeline.transform(df_in)

        # 3) Scale
        x_scaled = self.scaler.transform(x_processed)

        # 4) Predict
        proba = self.clf.predict_proba(x_scaled)[0][1]
        label = "repurpose" if proba >= 0.5 else "not_repurpose"

        # 5) SHAP explanation (TreeExplainer)
        explainer = shap.TreeExplainer(self.clf, feature_perturbation="interventional")
        shap_values = explainer.shap_values(x_scaled)[1]  # class=1
        shap_dict = {x_processed.columns[i]: float(shap_values[0, i]) for i in range(len(x_processed.columns))}

        return label, float(proba), shap_dict

    def retrain(self, complete_feature_df: pd.DataFrame, label_series: pd.Series):
        """
        Retrain on a DataFrame of all previous features + a Series of corresponding labels.
        1) Preprocess features via FeaturePipeline
        2) Fit a new StandardScaler on X
        3) Scale X, then fit a new RandomForestClassifier
        4) Bump version from 'vN' → 'v(N+1)' and save pickles
        """
        # 1) Preprocess
        X = FeaturePipeline.transform(complete_feature_df)

        # 2) Fit new scaler
        self.scaler = StandardScaler().fit(X)
        X_scaled = self.scaler.transform(X)

        # 3) Fit new classifier
        self.clf = RandomForestClassifier(n_estimators=100, random_state=42)
        self.clf.fit(X_scaled, label_series)

        # 4) Bump version
        with open(self.meta_path, "r") as f:
            meta = json.load(f)
        latest = meta["current_version"]
        num = int(latest.strip("v")) + 1
        new_version = f"v{num}"
        self._save_version(new_version)
