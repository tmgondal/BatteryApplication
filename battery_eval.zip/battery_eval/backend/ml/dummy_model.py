# backend/ml/dummy_model.py

import pickle
import os
import random

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "dummy_model.pkl")


def load_model_and_predict(features: dict) -> float:
    """
    A placeholder that “loads” a model and returns a random score from 0→1.
    Replace this with actual pickle.load(...) once you have a trained model.
    """

    # If you had a real pickle file:
    # with open(MODEL_PATH, "rb") as f:
    #     clf = pickle.load(f)
    #     # Example: ensure the feature vector matches training shape/order
    #     feat_vector = [features[k] for k in sorted(features.keys())]
    #     score = clf.predict_proba([feat_vector])[0, 1]
    #     return float(round(score, 4))

    # For now, just return a random dummy score
    return round(random.uniform(0.0, 1.0), 4)
