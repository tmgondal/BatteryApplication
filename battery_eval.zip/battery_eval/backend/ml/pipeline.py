import pandas as pd

class FeaturePipeline:
    """
    Static methods to ensure:
      - All expected features exist (fill missing with 0)
      - Columns are ordered consistently for the ML model
    Expected features:
      ["Rs", "Rct", "Z_imag_min", "warburg",
       "capacity", "R_internal", "SoH", "efficiency", "DoD"]
    """

    @staticmethod
    def transform(df: pd.DataFrame) -> pd.DataFrame:
        """
        Input: df with columns matching any subset of expected features.
        Steps:
          1. For any missing feature, add column with default 0.0
          2. Reorder to exactly [Rs, Rct, Z_imag_min, warburg, capacity, R_internal, SoH, efficiency, DoD]
        Returns: new DataFrame with exactly those 9 columns.
        """
        required = [
            "Rs", "Rct", "Z_imag_min", "warburg",
            "capacity", "R_internal", "SoH", "efficiency", "DoD"
        ]
        for col in required:
            if col not in df.columns:
                df[col] = 0.0
        return df[required].copy()
