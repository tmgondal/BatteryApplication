def shap_to_dict(shap_values_array, feature_names):
    """
    Given a 2D numpy array shap_values_array (shape: 1 × n_features)
    and a list of feature_names (length = n_features), return:
      { feature_name: shap_value }
    """
    return {feature_names[i]: float(shap_values_array[0, i]) for i in range(len(feature_names))}
