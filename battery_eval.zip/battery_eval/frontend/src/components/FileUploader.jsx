import React, { useState } from "react";

export default function FileUploader({ onUploadComplete }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function handleChange(e) {
    setSelectedFile(e.target.files[0]);
    setError("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!selectedFile) {
      setError("Please select an EIS file to upload.");
      return;
    }

    setLoading(true);
    setError("");
    const formData = new FormData();
    formData.append("eis_file", selectedFile);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      if (data.status === "success") {
        onUploadComplete(data);
      } else {
        setError(data.message || "Server returned an error.");
      }
    } catch (err) {
      setError("Network error: Unable to reach the server.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow">
      <label className="block text-gray-700 font-medium mb-2">
        Select EIS Excel/CSV File
      </label>
      <input
        type="file"
        accept=".xls,.xlsx,.csv"
        onChange={handleChange}
        className="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4
                   file:rounded file:border-0 file:text-sm file:font-semibold
                   file:bg-blue-50 file:text-blue-700
                   hover:file:bg-blue-100"
      />
      <button
        type="submit"
        disabled={loading}
        className="mt-4 w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? "Uploading..." : "Upload & Analyze"}
      </button>
      {error && <p className="mt-2 text-red-500">{error}</p>}
    </form>
  );
}
