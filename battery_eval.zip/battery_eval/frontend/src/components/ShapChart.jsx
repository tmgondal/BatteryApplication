import React from "react";

export default function ShapChart({ runId }) {
  const chartUrl = `/api/report/${runId}/shap.png`;

  return (
    <div className="mt-6 bg-white p-4 rounded-lg shadow">
      <h3 className="font-medium mb-2">SHAP Feature Importance Chart</h3>
      <img
        src={chartUrl}
        alt="SHAP bar chart"
        className="w-full h-auto border"
      />
    </div>
  );
}
