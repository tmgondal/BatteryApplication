import React from "react";

export default function ResultCard({ data }) {
  const { id, features, prediction, probability, shap_values, report_url } = data;

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-semibold mb-4">Results for Run ID: {id}</h2>

      <div className="mb-4">
        <span className="font-medium">Prediction: </span>
        <span className={prediction === "repurpose" ? "text-green-600" : "text-red-600"}>
          {prediction.toUpperCase()}
        </span>
        <span className="ml-2 text-gray-500">
          ({(probability * 100).toFixed(1)}%)
        </span>
      </div>

      <div className="mb-4">
        <h3 className="font-medium">Extracted Features:</h3>
        <ul className="list-disc list-inside">
          {Object.entries(features).map(([key, value]) => (
            <li key={key}>
              <span className="font-light">{key}</span>: {typeof value === "number" ? value.toFixed(4) : value}
            </li>
          ))}
        </ul>
      </div>

      <div className="mb-4">
        <h3 className="font-medium">SHAP Values:</h3>
        <ul className="list-disc list-inside">
          {Object.entries(shap_values).map(([key, value]) => (
            <li key={key}>
              <span className="font-light">{key}</span>: {typeof value === "number" ? value.toFixed(4) : value}
            </li>
          ))}
        </ul>
      </div>

      <div className="flex space-x-4">
        <a
          href={report_url}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          target="_blank"
          rel="noopener noreferrer"
        >
          Download Excel Report
        </a>
        <a
          href={`/api/report/${id}/shap.png`}
          className="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600"
          target="_blank"
          rel="noopener noreferrer"
        >
          View SHAP Chart
        </a>
      </div>
    </div>
  );
}
