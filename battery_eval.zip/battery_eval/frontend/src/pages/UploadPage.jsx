import React, { useState } from "react";
import FileUploader from "../components/FileUploader";
import ResultCard from "../components/ResultCard";
import ShapChart from "../components/ShapChart";

export default function UploadPage() {
  const [resultData, setResultData] = useState(null);

  return (
    <div className="max-w-3xl mx-auto py-8">
      <h1 className="text-3xl font-bold text-center mb-6">
        Battery Second‐Life Evaluator
      </h1>

      <FileUploader onUploadComplete={setResultData} />

      {resultData && (
        <div className="mt-8">
          <ResultCard data={resultData} />
          <ShapChart runId={resultData.id} />
        </div>
      )}
    </div>
  );
}
