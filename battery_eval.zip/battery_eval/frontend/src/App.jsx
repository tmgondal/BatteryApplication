// frontend/src/App.jsx

import React, { useState } from "react";
import FileUploader from "./components/FileUploader";

function App() {
  const [eisResult, setEisResult] = useState(null);
  const [hppcResult, setHppcResult] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-3xl font-semibold mb-6 text-center">
        Battery Second‐Life Evaluation
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* EIS Upload */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-medium mb-4">Upload EIS Excel</h2>
          <FileUploader
            endpoint="http://localhost:5000/upload/eis"
            onSuccess={(data) => setEisResult(data)}
          />
          {eisResult && (
            <div className="mt-4 p-4 bg-green-50 border-l-4 border-green-500">
              <h3 className="font-semibold">EIS Features & Model Score:</h3>
              <pre className="whitespace-pre-wrap text-sm">
                {JSON.stringify(eisResult, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* HPPC Upload */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-medium mb-4">Upload HPPC Excel</h2>
          <FileUploader
            endpoint="http://localhost:5000/upload/hppc"
            onSuccess={(data) => setHppcResult(data)}
          />
          {hppcResult && (
            <div className="mt-4 p-4 bg-blue-50 border-l-4 border-blue-500">
              <h3 className="font-semibold">HPPC Features & Model Score:</h3>
              <pre className="whitespace-pre-wrap text-sm">
                {JSON.stringify(hppcResult, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
